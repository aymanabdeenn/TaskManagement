package taskManagement;

import java.util.ArrayList;
import java.io.Serializable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;


public class User implements Serializable{
	String username;
	String password;
	int teamID;
	
	public User(String username , String password) {
		this.username = username;
		this.password = password;
		this.teamID = 0;
	}
	
	public User signUpUser() {
		File file = new File("Users.ser");
		try {
			if(!file.exists()) {
				file.createNewFile();
				ArrayList<User> users = new ArrayList<>();
				users.add(this);
				saveUsersList(users);
				System.out.println("Signed Up Successfully.");
				return this;
			}
			else {
				ArrayList<User>users = getUsersList();
				if(isUserInUsers(this , users) != null) {System.out.println("Username already occupied."); return null;} 
				else {users.add(this); saveUsersList(users); System.out.println("Signed Up Successfully."); return this;}
			}
		}
		catch(IOException e) {System.out.println("An error occured while creating the file (Users.ser)."); return null;}
	}
	
	
	public User signInUser() {
		File file = new File("Users.ser");
		
		if(!file.exists()) {System.out.println("The file (Users.ser) does not exist."); return null;} 
		else {
			ArrayList<User> users = getUsersList();
			if(isUserInUsers(this , users) != null && checkPassword(this , users)) {System.out.println("Logged In Successfully."); return this;} 
			else if(isUserInUsers(this , users) != null && !checkPassword(this , users)) System.out.println("Wrong password.");
			else System.out.println("Wrong username.");
			return null;
			}
	}
	
	
	public String getUsername() {return this.username;}
	public int getTeamID() {return this.teamID;}
	public void setTeamID(int teamID) {this.teamID = teamID;}
	public void setUsername(String username) {this.username = username;}
	
	///////////////////////////HELPER FUNCTIONS/////////////////////////////////
	
	public void saveUsersList(ArrayList<User> users) {
		try {
			FileOutputStream fos = new FileOutputStream("Users.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(users);
			fos.close();
			oos.close();
		}
		catch(IOException e) {System.out.println("An error occured while adding the user to the file (Users.ser).");}
	}
	
	public ArrayList<User> getUsersList(){
		File file = new File("Users.ser");
		try {
			if(!file.exists()) {System.out.println("The file (Users.ser) does not exist."); return new ArrayList<User>();}
			else {
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream ois = new ObjectInputStream(fis);
				ArrayList<User> users = (ArrayList<User>) ois.readObject();
				fis.close();
				ois.close();
				return users;
			}
		}
		catch(IOException | ClassNotFoundException e) {System.out.println("An error has occured while reading the file (Users.ser)."); return new ArrayList<User>();}
	}
	
	public User isUserInUsers(User user , ArrayList<User> users) {
		for(User aUser : users) {
			if(aUser.username.equals(user.username)) return aUser;
		}
		return null;
	}
	
	public boolean checkPassword(User user , ArrayList<User> users) {
		for(User aUser : users) {
			if(aUser.username.equals(user.username)) {
				if(aUser.password.equals(user.password)) return true;
			}
		}
		return false;
	}
	
	public void printUsers() {
		ArrayList<User> users = getUsersList();
		System.out.println("--------Avaliable Users--------");
		for(User user : users) System.out.println(user.username);
		System.out.println("--------End of Users--------");
	}
	
	public void printAvaliableUsers() {
		ArrayList<User> users = getUsersList();
		for(User user : users) if(user.teamID == 0) System.out.println(user.username);
	}

	
}
