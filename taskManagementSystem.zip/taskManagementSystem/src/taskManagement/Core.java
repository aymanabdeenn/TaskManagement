package taskManagement;

import java.util.Scanner;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Core {
	
	public void createTask(Scanner scanner) {
		System.out.println("Task's Title: ");
		String title = scanner.nextLine();
		System.out.println("Task's Due Date: (YY/MM/DD)");
		String dueDate = scanner.nextLine();
		System.out.println("Task's Description: ");
		String description = scanner.nextLine();
		Task task = new Task(title, description , dueDate);
		task.addTaskToList();
	}
	
	public void createTeamAndAddMembers(Scanner scanner) {
		System.out.println("Enter Team Name: ");
		String name = scanner.nextLine();
		System.out.println("Enter Team ID: ");
		int ID = scanner.nextInt();
		scanner.nextLine();
		Team team = new Team(name , ID);
		
		User dummyUser = new User("" , "");
		ArrayList<User> users = dummyUser.getUsersList();
		while(true) {
			System.out.println("--------Avaliable Users--------");
			for(User aUser : users) {
				if(aUser.getTeamID() == 0) {
					System.out.println(aUser.getUsername());
					
				}
			}
			System.out.println("--------End of Users--------");
			
			System.out.println("Enter the user's name: ");
			String userName = scanner.nextLine();
		    dummyUser = dummyUser.isUserInUsers(new User(userName , ""), users);
		    if(dummyUser == null) {System.out.println("User not found."); break;}
		    else {team.users.add(dummyUser); dummyUser.setTeamID(team.getID());}
		    System.out.println("Do you want to add more users?[YES/NO]");
		    String choiceStr = scanner.nextLine();
		    if(choiceStr.equals("YES")) continue;
		    else {dummyUser.saveUsersList(users); break;} 
		}
	}
	
	public void assignTaskToMember(Scanner scanner) {
		Task dummyTask = new Task("" , "" , "");
		ArrayList<Task> tasks = dummyTask.getTasksList();
		
		System.out.println("--------Avaliable Tasks--------");
		for(Task task : tasks) if(task.getStatus().equals("To-Do")) System.out.println(task.getTitle() + "		" + task.getDueDate());
		System.out.println("--------End of Tasks--------");
		
		System.out.println("Choose a Task: ");
		String taskChoice = scanner.nextLine();
		dummyTask.setTitle(taskChoice);
		dummyTask = dummyTask.isTaskInTasks(tasks);
		if(dummyTask != null) {
			User dummyUser = new User("" , "");
			ArrayList<User> users = dummyUser.getUsersList();
			dummyUser.printUsers();
			System.out.println("Choose a User: ");
			String userChoice = scanner.nextLine();
			dummyUser.setUsername(userChoice);
			dummyUser = dummyUser.isUserInUsers(dummyUser , users);
			if(dummyUser != null) {
				dummyTask.setAssingee(dummyUser);
				dummyTask.setStatus("Pending");
				dummyUser.saveUsersList(users);
			}
			else {System.out.println("User Not Found.");}
			dummyTask.saveTasksList(tasks);
			System.out.println("The task (" + dummyTask.getTitle() + ") has been assigned successfully. ");
		}
		else System.out.println("Task Not Found.");
		
	}
	
	public void printTaskReport(Scanner scanner) {
		Task dummyTask = new Task("" , "" , "");
		ArrayList<Task> tasks = dummyTask.getTasksList();
		System.out.println("--------Avaliable Tasks--------");
		for(int i = 0 ; i < tasks.size(); i++) {
			dummyTask = tasks.get(i);
			System.out.println("Task Title: " + dummyTask.getTitle());
			System.out.println("Task Status: " + dummyTask.getStatus());
			System.out.println("Task Assignee: " + dummyTask.getAssignee());
			System.out.println("Progress: " + dummyTask.getProgress());
			if(differenceInTime(dummyTask) < 0) System.out.println("(Delayed)");
			
			if(i < tasks.size() -1) System.out.println("-------------------------------------------------");
		}
		System.out.println("--------End of Tasks--------");

	}
	
	public int differenceInTime(Task task) {
		String[] dueDateStr = task.getDueDate().split("/");
		LocalDate dueDate = LocalDate.of(Integer.parseInt(dueDateStr[0]) , Integer.parseInt(dueDateStr[1]) , Integer.parseInt(dueDateStr[2]));
		LocalDate currentDate = LocalDate.now();
		long difference = ChronoUnit.DAYS.between(currentDate, dueDate);
		return (int)difference;
	}
	
	public void trackTaskProgress(Scanner scanner , User user) {
		Task dummyTask = new Task("" , "" , "");
		ArrayList<Task> tasks = dummyTask.getTasksList();
		System.out.println("--------" + user.getUsername() + "'s Tasks--------");
		for(int i = 0 ; i < tasks.size(); i++) {
			Task task = tasks.get(i);
			if (task.assignee.equals(user.username)) {
				System.out.println(task.getTitle() + "		" + task.getProgress() + "		" + task.getDueDate());
			} 
		}
		System.out.println("--------End of tasks--------");
		
		System.out.println("Choose a Task: ");
		String taskChoice = scanner.nextLine();
		dummyTask.setTitle(taskChoice);
		dummyTask = dummyTask.isTaskInTasks(tasks);
		if(dummyTask != null) {
			System.out.println("Enter the new percentage: ");
			String percentage = scanner.nextLine();
			dummyTask.setProgress(percentage);
			if(Integer.parseInt(percentage.replace("%" , "")) >= 100) dummyTask.setStatus("Done");
			dummyTask.saveTasksList(tasks);
		}
		else System.out.println("Task Not Found.");
	}
	
	public void viewTaskDetails(User user) {
		Task dummyTask = new Task("" , "" , "");
		ArrayList<Task> tasks = dummyTask.getTasksList();
		System.out.println("--------" + user.getUsername() + "'s Tasks--------");
		for(int i = 0 ; i < tasks.size(); i++) {
			Task task = tasks.get(i);
			if (task.assignee.equals(user.username)) {
				System.out.println("Task Title: " + task.getTitle());
				System.out.println("Task Description: " + task.getDescription());
				System.out.println("Task Due Date: " + task.getDueDate());
				System.out.println("Task Due Date: " + task.getStatus());
				System.out.println("Task Progress: " + task.getProgress());
				System.out.println("-------------------------------------------------");
			} 
		}
	}

}
