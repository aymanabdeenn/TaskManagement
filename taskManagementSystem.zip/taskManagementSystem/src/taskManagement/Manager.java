package taskManagement;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Manager extends User{
	ArrayList<User> teamMembers = new ArrayList<>();
	
	public Manager(String username , String password) {
		super(username , password);
	}
	
	public Manager signUpManager() {
		File file = new File("Managers.ser");
		try {
			if(!file.exists()) {
				file.createNewFile();
				ArrayList<Manager> managers = new ArrayList<>();
				managers.add(this);
				saveManagersList(managers);
				System.out.println("Signed Up Successfully.");
				return this;
			}
			else {
				ArrayList<Manager>managers = getManagersList();
				if(isManagerInManagers(this , managers) != null) {System.out.println("Username already occupied."); return null;} 
				else {managers.add(this); saveManagersList(managers); System.out.println("Signed Up Successfully."); return this;}
			}
		}
		catch(IOException e) {System.out.println("An error occured while creating the file (Managers.ser)."); return null;}
		
	}
	
	
	public Manager signInManager() {
		File file = new File("Managers.ser");
		if(!file.exists()) {System.out.println("The file (Managers.ser) does not exist."); return null;} 
		ArrayList<Manager> managers = getManagersList();
		if(isManagerInManagers(this , managers) != null && checkPassword(this , managers)) {System.out.println("Logged In Successfully."); return this;}
		else if(isManagerInManagers(this , managers) != null) System.out.println("Wrong password.");
		else System.out.println("Wrong Username.");
		return null;
	}
	
	///////////////////////////HELPER FUNCTIONS/////////////////////////////////
	public void  saveManagersList(ArrayList<Manager> managers) {
		try {
			FileOutputStream fos = new FileOutputStream("Managers.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(managers);
			fos.close();
			oos.close();
		}
		catch(IOException e) {System.out.println("An error occured while adding the user to the file (Managers.ser).");}
	}
	
	public ArrayList<Manager> getManagersList(){
		File file = new File("Managers.ser");
		try {
			if(!file.exists()) {System.out.println("The file (Managers.ser) does not exist."); return new ArrayList<Manager>();}
			else {
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream ois = new ObjectInputStream(fis);
				ArrayList<Manager> managers = (ArrayList<Manager>) ois.readObject();
				fis.close();
				ois.close();
				return managers;
			}
		}
		catch(IOException | ClassNotFoundException e) {System.out.println("An error has occured while reading the file (Managers.ser)."); return new ArrayList<Manager>();}
	}
	
	public Manager isManagerInManagers(Manager manager , ArrayList<Manager> managers) {
		for(Manager aManager : managers) {
			if(aManager.username.equals(manager.username)) return aManager;
		}
		return null;
	}
	
	public boolean checkPassword(Manager manager , ArrayList<Manager> managers) {
		for(Manager aManager : managers) {
			if(aManager.username.equals(manager.username)) {
				if(aManager.password.equals(manager.password)) return true;
			}
		}
		return false;
	}
	
	public void printManagers() {
		ArrayList<Manager> managers = getManagersList();
		for(Manager manager : managers) System.out.println(manager.username);
	}
	
	
}
