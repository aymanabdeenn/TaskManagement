package taskManagement;

import java.util.Scanner;
import java.util.ArrayList;

public class UI {
	public Scanner scanner;
	public Core core;
	
	public UI(Scanner scanner) {
		this.scanner = scanner;
		this.core = new Core();
	}
	
	public Scanner getScanner() {return this.scanner;}
	
	public void mainPage() {
			Scanner scanner = getScanner();
		
			while(true) {
				System.out.println("[1] Sign Up as Manager\n[2] Sign Up as User (Team Member)\n[3] Sign In as Manager\n[4] Sign In as User (Team Member)\n[5] Exit");
				System.out.println("Enter your choice");
				int choice = scanner.nextInt();
				scanner.nextLine();
				if(choice <= 0 || choice > 5) System.out.println("Invalid choice.");
	
				if(choice == 1) {
					System.out.println("Username: ");
					String username = scanner.nextLine();
					System.out.println("Password: ");
					String password = scanner.nextLine();
					Manager manager = new Manager(username , password);
				    manager.signUpManager();
				}
				else if(choice == 2) {
					System.out.println("Username: ");
					String username = scanner.nextLine();
					System.out.println("Password: ");
					String password = scanner.nextLine();
					User user = new User(username , password);
					user.signUpUser();
				}
				else if(choice == 3) {
					System.out.println("Username: ");
					String username = scanner.nextLine();
					System.out.println("Password: ");
					String password = scanner.nextLine();
					Manager manager = new Manager(username , password);
					manager = manager.signInManager();
					if(manager != null) SignInManagerUI();
				} 
				
				else if(choice == 4){
					System.out.println("Username: ");
					String username = scanner.nextLine();
					System.out.println("Password: ");
					String password = scanner.nextLine();
					User user = new User(username , password);
					user = user.signInUser();
					if(user != null) SignInUserUI(user);
				} 
				else if(choice == 5) {System.out.println("End..."); break;}
			}
			
	}
	
	public void SignInManagerUI() {
		Scanner scanner = getScanner();
		
		
		while(true) {
			
			System.out.println("[1] Create New Task\n[2] Create New Team And Assign User To Team\n[3] Assing Task To Team Member\n[4] Generate Task Report\n[5] Sign Out");
			System.out.println("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();
			if(choice <= 0 || choice > 5) System.out.println("Invalid choice.");
			
			if(choice == 1) {
				core.createTask(scanner);
			}
			
			else if(choice == 2) {
				core.createTeamAndAddMembers(scanner);
			}
			
			else if(choice == 3) {
				core.assignTaskToMember(scanner);
			}
			
			else if(choice == 4) {
				core.printTaskReport(scanner);
			}
			else if(choice == 5) {System.out.println("Signed Out Successfully...");break;} 
		}
		
	}
	
	public void SignInUserUI(User user) {
		Scanner scanner = getScanner();
		
		while(true) {
			System.out.println("[1] Track Task Progress (Update Task)\n[2] View Task Details\n[3] Sign Out");
			System.out.println("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();
			if(choice <= 0 || choice > 3) System.out.println("Invalid choice.");
			
			if(choice == 1) core.trackTaskProgress(scanner , user);
			else if(choice == 2) core.viewTaskDetails(user);
			else if(choice == 3) {System.out.println("Signed Out Successfully...");break;} 
		}
		
	}

}
