package taskManagement;

import java.util.Scanner;
import java.util.ArrayList;

public class TaskManagement {
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		UI ui = new UI(scanner);
		ui.mainPage();
		scanner.close();
	}

}
