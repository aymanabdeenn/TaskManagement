package taskManagement;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;


public class Task implements Serializable{
	String title;
	String description;
	String dueDate;
	String status;
	String assignee;
	String progress;
	
	public Task(String title, String description , String dueDate) {
		this.title = title;
		this.description = description;
		this.dueDate = dueDate;
		this.status = "To-Do";
		this.assignee = "Not assigned.";
		this.progress = "0%";
	}
	
	public String getStatus() {return this.status;}
	public String getTitle() {return this.title;}
	public String getDueDate() {return this.dueDate;}
	public String getProgress() {return this.progress;}
	public String getAssignee() {return this.assignee;}
	public String getDescription() {return this.description;}
	public void setAssingee(User user) {this.assignee = user.getUsername();}
	public void setTitle(String title) {this.title = title;}
	public void setStatus(String status) {this.status = status;}
	public void setProgress(String progress) {this.progress = progress;}
	
	public void addTaskToList() {
		File file = new File("Tasks.ser");
		try {
			ArrayList<Task> tasks;
			if(!file.exists()) {
				file.createNewFile();
				tasks = new ArrayList<>();
				
			}
			else {
				tasks = getTasksList();
			}
			tasks.add(this);
			saveTasksList(tasks);
			System.out.println("The task has created successfully.");
		}
		catch(IOException e) {System.out.println("An error occured while creating the file (Tasks.ser).");}
	}
	
	public void saveTasksList(ArrayList<Task> tasks) {
		try {
			FileOutputStream fos = new FileOutputStream("Tasks.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(tasks);
			fos.close();
			oos.close();
		}
		catch(IOException e) {System.out.println("An error occured while adding the task to the file (Tasks.ser).");}
	}
	
	public ArrayList<Task> getTasksList(){
		File file = new File("Tasks.ser");
		try {
			if(!file.exists()) {System.out.println("The file (Tasks.ser) does not exist."); return new ArrayList<Task>();}
			else {
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream ois = new ObjectInputStream(fis);
				ArrayList<Task> tasks = (ArrayList<Task>) ois.readObject();
				fis.close();
				ois.close();
				return tasks;
			}
		}
		catch(IOException | ClassNotFoundException e) {System.out.println("An error has occured while reading the file (Tasks.ser)."); return new ArrayList<Task>();}
	}
	
	public Task isTaskInTasks(ArrayList<Task> tasks) {
		for(Task aTask : tasks) {
			if(aTask.title.equals(this.title)) return aTask;
		}
		return null;
	}
	
	public void printTask() {
		ArrayList<Task> tasks = getTasksList();
		for(Task task : tasks) {System.out.println(task.title + " " + task.dueDate + " " + task.progress + " " + task.assignee);} 
	}
}
