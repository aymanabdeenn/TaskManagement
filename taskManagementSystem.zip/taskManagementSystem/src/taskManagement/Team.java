package taskManagement;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Team implements Serializable{
	String name;
	int id;
	ArrayList<User> users = new ArrayList<>();
	
	public Team(String name , int id) {
		this.name = name;
		this.id = id;
		
		File file = new File("Teams.ser");
		try {
			ArrayList<Team> teams;
			if(!file.exists()) {
				file.createNewFile();
				teams = new ArrayList<>();
				System.out.println("The team has been created successfully.");
			}
			else {
				teams = getTeamsList();
			}
			
			teams.add(this);
			saveTeamsList(teams);
		}
		catch(IOException e) {System.out.println("An error occured while creating the file (Teams.ser)");}
	}

	public int getID() {return this.id;}
	
	/////////////////////Helper Methods//////////////////////////  
	public void saveTeamsList(ArrayList<Team> teams) {
		try {
			FileOutputStream fos = new FileOutputStream("Teams.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(teams);
			fos.close();
			oos.close();
		}
		catch(IOException e) {System.out.println("An error occured while adding the user to the file (Teams.ser)");}
	}
	
	public ArrayList<Team> getTeamsList(){
		File file = new File("Teams.ser");
		try {
			if(!file.exists()) {System.out.println("The file (Teams.ser) does not exist."); return new ArrayList<Team>();}
			else {
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream ois = new ObjectInputStream(fis);
				ArrayList<Team> teams = (ArrayList<Team>) ois.readObject();
				fis.close();
				ois.close();
				return teams;
			}
		}
		catch(IOException | ClassNotFoundException e) {System.out.println("An error has occured while reading the file (Teams.ser)."); return new ArrayList<Team>();}
	}
	
	public void printTeams() {
		ArrayList<Team> teams = getTeamsList();
		for(Team team : teams) {
			for(int i = 0 ; i<team.users.size() ; i++) {System.out.println(team.users.get(i).username); System.out.println(team.users.get(i).getTeamID());}
		}
	}
	
}
